
import roboticstoolbox as rtb
from spatialmath import SE3
import cv2
from mpl_toolkits import mplot3d
from matplotlib import pyplot as plt
import spatialmath.base as base
import numpy as np

def modelscara(q, t, i, I1, I2, l1, l2, l3, lc1, lc2, lc3, m1, m2, Jm1, Jm2, Jm3, r1, r2, r3, R1, R2, R3, Km1, Km2, Km3, Kb1, Kb2, Kb3,
               Bm1, Bm2, Bm3, zeta, wn, K1, K2, K3,q1_poly,q2_poly,q3_poly):

    dt = 0.01 # step size change accordingly
    t1 = q[0]
    t2 = q[1]
    t3 = q[2]
    #joint rates
    dt1 = q[3]
    dt2 = q[4]
    dt3 = q[5]

    # cubic desired trajectory
    qd1 = q1_poly[0]+q1_poly[1]*t+q1_poly[2]*t**2+q1_poly[3]*t**3
    qd2 = q2_poly[0] + q2_poly[1] * t + q2_poly[2] * t ** 2 + q2_poly[3] * t ** 3
    qd3 = q3_poly[0] + q3_poly[1] * t + q3_poly[2] * t ** 2 + q3_poly[3] * t ** 3
    # desired velocity
    dqd1 = q1_poly[1]  + 2*q1_poly[2] * t+ 3*q1_poly[3] * t **2
    dqd2 = q2_poly[1]  + 2*q2_poly[2] * t+ 3*q2_poly[3] * t **2
    dqd3 = q3_poly[1]  + 2*q3_poly[2] * t + 3*q3_poly[3] * t **2
    # desired acceleration
    ddqd1 =  2*q1_poly[2]+ 6*q1_poly[3] * t
    ddqd2 =  2*q2_poly[2]+ 6*q2_poly[3] * t
    ddqd3 =  2*q3_poly[2] + 6*q3_poly[3] * t

    # desired accl vector
    tdd = np.array([[ddqd1],[ddqd2],[ddqd2]])

    tdd = np.reshape(tdd,(3,1))
    # actual velocity vector
    td = np.array([[dt1],[dt2],[dt3]])

    tau = np.transpose(np.zeros(3))
    # Define Robot using PeterCorke toolbox just substitute non variable DH parameters Inertia and mass
    robot1 = rtb.DHRobot(
        [
            rtb.RevoluteDH(alpha=0, a=0.5, d=0.2, I=np.array([[0,0,0],[0,0,0],[0,0,1/12]]), m=1),
            rtb.RevoluteDH(alpha=np.pi, a=0.5, d=0, I=np.array([[0,0,0],[0,0,0],[0,0,1/12]]), m=1),
            rtb.PrismaticDH(theta=0, alpha=0, a=0, I=np.array([[0,0,0],[0,0,0],[0,0,1/12]]), m=1),
        ], name="scararob", gravity=[0, 0, 9.81])

    # Get D,C,phi
    D = robot1.inertia([t1,t2,t3])
    C = robot1.coriolis([t1,t2,t3],[dt1,dt2,dt3])
    phi = robot1.gravload([t1,t2,t3])
    phi = np.reshape(phi, (3, 1))

    #diagonal terms D to dkk
    dkk = np.array([[D[0][0], 0, 0],[0, D[1][1],0],[0, 0,D[2][2]]])
    # modelling disturbance, you can more disturbances here
    dk =   np.matmul(C, td) +np.matmul((D-dkk), tdd) +phi
    #motor parameters
    Jm = np.array([[Jm1,0,0],[0,Jm2,0],[0,0,Jm3]])
    Jeff1 = Jm1 + r1 * r1 * dkk[0][0]
    Jeff2 = Jm2 + r2 * r2 * dkk[1][1]
    Jeff3 = Jm3 + r3 * r3 * dkk[2][2]
    Beff1 = Bm1 + Kb1 * Km1 / R1
    Beff2 = Bm2 + Kb2 * Km2 / R2
    Beff3 = Bm3 + Kb3 * Km3 / R2
    K1 = Km1 / R1
    K2 = Km2 / R2
    K3 = Km3 / R3
    #gear ratio will assume same gear ratio so will only use scalar r1
    r = np.array([[r1, 0, 0],[0, r2,0],[0,0,r3]])
    Jeff = np.array([[Jeff1, 0,0],[0, Jeff2,0],[0,0,Jeff3]])
    Jeffinv = np.linalg.inv(Jeff)
    Beff = np.array([[Beff1, 0,0],[0, Beff2,0],[0,0,Beff3]])

    K = np.array([[K1,0,0],[0,K2,0],[0,0,K3]])/dt

    Kinv = np.linalg.inv(K)

    # compute errors
    e = np.array([[qd1-q[0]],[qd2-q[1]],[qd3-q[2]]])
    e = np.reshape(e,(3,1))
    ed = np.array([[0 - q[3]], [0 - q[4]], [0 - q[5]]])
    ed = np.reshape(e, (3, 1))

    Kp = wn * wn * np.matmul(Jeff,  Kinv)
    Kd = np.matmul((2 * zeta * wn * Jeff - Beff ),Kinv) # change zeta here

    dt = 0.01
    # if i == 0:
    #     tprev = 0
    #     dt = t - tprev
    # else:
    #     dt = t - tprev
    #disp(size(dt));
    #sum = np.matmul(Ki, e) * dt

    V = np.matmul(Kp , e) + np.matmul(Kd ,ed) # voltage control input

    # dynamic equation in joint varaibles
    ddq = np.matmul(np.linalg.inv(Jeff),(r1*np.matmul(K ,V) - (r1**2)*(dk)- np.matmul(Beff , td)))
    # find statedot
    dq = [q[3],q[4],q[5],ddq[0][0],ddq[1][0],ddq[2][0]]

    print('t= '+str(t))
    # tprev = t used for Integral
    # i = i+1
    return dq



